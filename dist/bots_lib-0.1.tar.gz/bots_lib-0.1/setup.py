from setuptools import setup, find_packages

setup(
    name="bots_lib",
    version="0.1",
    url="https://github.com/Ninzalo/bots_lib",
    license="MIT",
    author="Ninzalo",
    # description='Add static script_dir() method to Path',
    packages=find_packages(),
    zip_safe=False,
)
